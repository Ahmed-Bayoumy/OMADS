# # ------------------------------------------------------------------------------------#
# #  Mesh Adaptive Direct Search - ORTHO-MADS (MADS)                                    #
# #                                                                                     #
# #  Author: Ahmed H. Bayoumy                                                           #
# #  email: ahmed.bayoumy@mail.mcgill.ca                                                #
# #                                                                                     #
# #  This program is free software: you can redistribute it and/or modify it under the  #
# #  terms of the GNU Lesser General Public License as published by the Free Software   #
# #  Foundation, either version 3 of the License, or (at your option) any later         #
# #  version.                                                                           #
# #                                                                                     #
# #  This program is distributed in the hope that it will be useful, but WITHOUT ANY    #
# #  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A    #
# #  PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more details.   #
# #                                                                                     #
# #  You should have received a copy of the GNU Lesser General Public License along     #
# #  with this program. If not, see <http://www.gnu.org/licenses/>.                     #
# #                                                                                     #
# #  You can find information on OMADS at                                               #
# #  https://github.com/Ahmed-Bayoumy/OMADS                                             #
# #  Copyright (C) 2022  Ahmed H. Bayoumy                                               #
# # ------------------------------------------------------------------------------------#

# import copy
# from dataclasses import dataclass
# import importlib
# import json
# from multiprocessing import freeze_support
# import os
# import sys
# import OMADS.POLL as PS
# import OMADS.SEARCH as SS
# from typing import List, Dict, Any
# import numpy as np
# if importlib.util.find_spec('BMDFO'):
#   from BMDFO import toy # type: ignore
# import time
# from .Point import Point
# from .CandidatePoint import CandidatePoint
# from ._common import logger, MSG_TYPE
# from ._globals import DESIGN_STATUS, SAMPLING_METHOD, SUCCESS_TYPES
# from .Barriers import Barrier, BarrierMO
# from .Parameters import Parameters
# from .Options import Options
# from .PostProcess import Output, PostMADS
# from .Metrics import Metrics
# from .Evaluator import Evaluator
# from .Optimizer import ConstraintsRelaxationParameters
# np.set_printoptions(legacy='1.21')

# @dataclass
# class MADS:
#   search: SS.efficient_exploration = None
#   search_VN: SS.VNS = None
#   poll: PS.Dirs2n = None
#   param: Parameters = None
#   evaluator: Evaluator = None
#   post: PostMADS = None
#   out: Output = None
#   outP: Output = None
#   options: Options = None
#   data: dict = None
#   xmin: CandidatePoint = None
#   iteration: int = 0
#   peval: int = 0
#   HT: Any = None
#   log: logger = None
#   B: Any = None
#   LAMBDA_k: float = 0.
#   RHO_k: float = 0.
#   tic: Any = None
#   toc: Any = None

#   def __init__(self, data: dict):
#     """ Initialize the log file """
#     self.log = logger()
#     if not os.path.exists(data["param"]["post_dir"]):
#       try:
#         os.mkdir(data["param"]["post_dir"])
#       except:
#         os.makedirs(data["param"]["post_dir"], exist_ok=True)

#     self.log.initialize(data["param"]["post_dir"] + "/OMADS.log")
#     self.log.log_msg(msg="Preprocess the MADS algorithim...", msg_type=PS.MSG_TYPE.INFO)
#     self.log.log_msg(msg="Preprocess the search step...", msg_type=PS.MSG_TYPE.INFO)
#     _, _, self.search, _, _, _, _, _, _ = SS.PreExploration(data).initialize_from_dict(log=self.log)
#     self.log.log_msg(msg="Preprocess the POLL step...", msg_type=PS.MSG_TYPE.INFO)
#     self.iteration, self.xmin, self.poll, self.options, self.param, self.post, self.out, self.B, self.outP = PS.PrePoll(data).initialize_from_dict(log=self.log, xs=self.search.xmin)
#     self.out.stepName = "Poll"
#     self.post.step_name = [f'Search: {self.search.type}']

#     self.HT = copy.deepcopy(self.poll.hashtable)

#   def search_step(self):
#     """ Reset success boolean """
#     if self.poll.bb_eval + self.search.bb_eval >= self.options.budget:
#       self.search.terminate
#       return
#     self.search.success = SUCCESS_TYPES.US
#     tic = time.perf_counter()
#     self.search.log = self.log
#     self.search.xmin = self.xmin
    
#     self.search.mesh.update()
#     self.search.constraints_RP.LAMBDA = self.search.xmin.LAMBDA = self.xmin.LAMBDA = self.poll.xmin.LAMBDA = self.LAMBDA_k
#     self.search.constraints_RP.RHO = self.search.xmin.RHO = self.xmin.RHO = self.poll.xmin.RHO = self.RHO_k
#     self.search.constraints_RP.hmax = self.search.xmin.hmax = self.xmin.hmax = self.poll.xmin.hmax
#     self.search.constraints_RP.constraints_type = copy.deepcopy(self.param.constraints_type)
#     if self.HT is not None:
#       self.search.hashtable = copy.deepcopy(self.HT)
#     if self.B is not None:
#       if isinstance(self.B, Barrier):
#         self.B.insert(self.search.xmin)
#         if self.B._filter is not None:
#           self.B.select_poll_center()
#           self.B.update_and_reset_success()
#       elif isinstance(self.B, BarrierMO) and self.iteration == 1:
#           self.B.init(evalPointList=[self.xmin])
        
    
#     # self.search.constraints_RP.hmax = B._h_max
    
#     if isinstance(self.B, Barrier):
#       self.search.constraints_RP.hmax = self.B._h_max
#       # TODO: Check whether the commented code below is needed
#       # if xmin.status == DESIGN_STATUS.FEASIBLE:
#       #   B.insert_feasible(self.search.xmin)
#       # elif xmin.status == DESIGN_STATUS.INFEASIBLE:
#       #   B.insert_infeasible(self.search.xmin)
#       # else:
#       #   B.insert(self.search.xmin)
#     elif isinstance(self.B, BarrierMO):
#       self.search.constraints_RP.hmax = self.B._hMax
#     """ Create the set of poll directions """
#     if self.search.type == SS.SEARCH_TYPE.VNS.name and self.search_VN is not None:
#       self.search_VN.active_barrier = self.B
#       self.search._candidate_points_set = self.search_VN.run()
#       if self.search_VN.stop:
#         print("Reached maximum number of VNS iterations!")
#         return
#       self.search.map_samples_from_coords_to_points(samples=self.search._candidate_points_set)
#     else:
#       vvp = vvs = []
#       bestFeasible: CandidatePoint = self.B._currentIncumbentFeas if isinstance(self.B, BarrierMO) else self.B._best_feasible
#       bestInf: CandidatePoint = self.B._currentIncumbentInf if isinstance(self.B, BarrierMO) else self.B.get_best_infeasible()
#       if bestFeasible is not None and bestFeasible.evaluated:
#         self.search.xmin = bestFeasible
#         vvp, _ = self.search.generate_sample_points(int(((self.search.dim+1)/2)*((self.search.dim+2)/2)) if self.search.ns is None else self.search.ns)
#       if bestInf is not None and bestInf.evaluated:
#       # if B._filter is not None and B.get_best_infeasible().evaluated:
#         xmin_bup = self.search.xmin
#         Prim_samples = self.search._candidate_points_set
#         self.search.xmin = bestInf#B.get_best_infeasible()
#         vvs, _ = self.search.generate_sample_points(int(((self.search.dim+1)/2)*((self.search.dim+2)/2)) if self.search.ns is None else self.search.ns)
#         self.search._candidate_points_set += Prim_samples
#         self.search.xmin = xmin_bup
      
#       if isinstance(vvs, list) and len(vvs) > 0:
#         vv = vvp + vvs
#       else:
#         vv = vvp


#     """ Save current poll directions and incumbent solution
#       so they can be saved later in the post dir """
#     if self.search.check_cache:
#       self.search.omit_duplicates()
#     if self.options.save_coordinates:
#       self.post.coords.append(self.search._candidate_points_set)
#       self.post.x_incumbent.append(self.search.xmin)
#     """ Reset success boolean """
#     self.search.success = SUCCESS_TYPES.US
#     """ Reset the BB output """
#     self.search.bb_output = []
#     xt = []
#     """ Serial evaluation for points in the poll set """
#     if self.search_VN is not None:
#       self.search.lb = self.search_VN.params.lb
#       self.search.ub = self.search_VN.params.ub
    
#     self.search.bb_handle.xmin = self.search.xmin
#     if not self.options.parallel_mode:
#       xt, self.post, self.peval = self.search.bb_handle.run_callable_serial_local(iter=self.iteration, peval=self.peval, eval_set=self.search._candidate_points_set, options=self.options, post=self.post, psize=self.search.mesh.getDeltaFrameSize().coordinates, stepName=f'Search: {self.search.type}', mesh=self.search.mesh, constraintsRelaxation=self.search.constraints_RP.__dict__, budget=self.options.budget)
#     else:
#       self.search.point_index = -1
#       """ Parallel evaluation for points in the samples set """
#       self.search.bb_eval, xt, self.post, self.peval = self.search.bb_handle.run_callable_parallel_local(iter=self.iteration, peval=self.peval, njobs=self.options.np, eval_set=self.search._candidate_points_set, options=self.options, post=self.post, mesh=self.search.mesh, stepName=f'Search: {self.search.type}', psize=self.search.mesh.getDeltaFrameSize().coordinates, constraintsRelaxation=self.search.constraints_RP.__dict__, budget=self.options.budget)
    
#     if self.search.bb_handle.constraintsRelaxation:
#       temp:ConstraintsRelaxationParameters = ConstraintsRelaxationParameters(**self.search.bb_handle.constraintsRelaxation)
#       for i in range(len(temp.LAMBDA)):
#         self.search.constraints_RP.LAMBDA[i] = temp.LAMBDA[i]
#       self.search.constraints_RP.RHO = temp.RHO
#       self.search.constraints_RP.constraints_type = temp.constraints_type
#       self.search.constraints_RP.hmax = temp.hmax
#       # if self.options.store_cache:
#       #   for xi in xt:
#       #     self.search.hashtable.hash_id = xi
#       #     if not self.search.hashtable._isPareto:
#       #       self.search.hashtable.add_to_best_cache(xi)
#     self.LAMBDA_k = self.search.bb_handle.constraintsRelaxation["LAMBDA"]
#     self.RHO_k = self.search.bb_handle.constraintsRelaxation["RHO"]
#     self.search.postprocess_evaluated_candidates(xt)
#     if isinstance(self.B, Barrier):
#       xpost: List[CandidatePoint] = self.search.master_updates(xt, self.peval, save_all_best=self.options.save_all_best, save_all=self.options.save_results)
#       if self.options.save_results:
#         for i in range(len(xpost)):
#           self.post.poll_dirs.append(xpost[i])
#       for xv in xt:
#         if xv.evaluated:
#           self.B.insert(xv)

#       """ Update the xmin in post"""
#       self.post.xmin = copy.deepcopy(self.search.xmin)
#       self.xmin = copy.deepcopy(self.search.xmin)


#       if self.iteration == 1:
#         self.search.vicinity_ratio = np.ones((len(self.search.xmin.coordinates),1))
      
#       """ Updates """
      
#       if self.search.success == SUCCESS_TYPES.FS:
#         dir: Point = Point(self.search.mesh._n)
#         dir.coordinates = self.search.xmin.direction.coordinates
#         # self.search.mesh.psize = np.multiply(self.search.mesh.get, 2, dtype=self.search.dtype.dtype)
#         self.search.mesh.enlargeDeltaFrameSize(direction=dir)
#         if self.search.sampling_t != SAMPLING_METHOD.ACTIVE.name:
#           self.search.update_local_region(region="expand")
#       elif self.search.success == SUCCESS_TYPES.US:
#         # self.search.mesh.psize = np.divide(self.search.mesh.psize, 2, dtype=self.search.dtype.dtype)
#         self.search.mesh.refineDeltaFrameSize()
#         if self.search.sampling_t != SAMPLING_METHOD.ACTIVE.name:
#           self.search.update_local_region(region="contract")
#     elif isinstance(self.B, BarrierMO):
#       xpost: List[CandidatePoint] = []
#       for i in range(len(xt)):
#         xpost.append(xt[i])
#       updated, updatedF, updatedInf = self.B.updateWithPoints(evalPointList=xpost, evalType=None, keepAllPoints=False, updateInfeasibleIncumbentAndHmax=True)
#       if not updated:
#         newMesh = None
#         if self.B._currentIncumbentInf:
#           self.B._currentIncumbentInf.mesh.refineDeltaFrameSize()
#           newMesh = copy.deepcopy(self.B._currentIncumbentFeas.mesh) if self.B._currentIncumbentFeas else copy.deepcopy(self.B._currentIncumbentInf.mesh) if self.B._currentIncumbentInf else None
#           self.B.updateCurrentIncumbents()
#           if self.search.sampling_t != SAMPLING_METHOD.ACTIVE.name:
#             self.search.update_local_region(region="contract")
#         if self.B._currentIncumbentFeas:
#           self.B._currentIncumbentFeas.mesh.refineDeltaFrameSize()
#           newMesh = copy.deepcopy(self.B._currentIncumbentFeas.mesh) if self.B._currentIncumbentFeas else copy.deepcopy(self.B._currentIncumbentInf.mesh) if self.B._currentIncumbentInf else None
#           self.B.updateCurrentIncumbents()
#           if self.search.sampling_t != SAMPLING_METHOD.ACTIVE.name:
#             self.search.update_local_region(region="contract")
        
#         if self.iteration == 1:
#           self.search.vicinity_ratio = np.ones((len(self.search.xmin.coordinates),1))
#         if newMesh:
#           self.search.mesh = newMesh
#         else:
#           self.search.mesh.refineDeltaFrameSize()
#           if self.search.sampling_t != SAMPLING_METHOD.ACTIVE.name:
#             self.search.update_local_region(region="contract")
#       else:
#         self.search.mesh = copy.deepcopy(self.B._currentIncumbentFeas.mesh) if updatedF else copy.deepcopy(self.B._currentIncumbentInf.mesh) if updatedInf else self.search.mesh
#         self.search.xmin = copy.deepcopy(self.B._currentIncumbentFeas) if updatedF else copy.deepcopy(self.B._currentIncumbentInf) if updatedInf else self.search.xmin
#         if self.search.sampling_t != SAMPLING_METHOD.ACTIVE.name:
#           self.search.update_local_region(region="expand")
      
#       for i in range(len(xpost)):
#         self.post.poll_dirs.append(xpost[i])
#       self.search.hashtable.best_hash_ID = []
#       self.search.hashtable.add_to_best_cache(self.B.getAllPoints())
#       self.post.xmin = self.B._currentIncumbentFeas if updatedF  else self.B._currentIncumbentInf if  updatedInf else self.search.xmin
      
#     self.search.mesh.update()
    
    
#     if self.options.display:
#       if self.log is not None:
#         self.log.log_msg(msg=self.post.__str__(), msg_type=MSG_TYPE.INFO)
#       print(self.post)

#     toc = time.perf_counter()
#     if self.log is not None:
#       self.log.log_msg(f" Run completed in {toc - tic:.4f} seconds", MSG_TYPE.INFO)
#       self.log.log_msg(msg=f" Success status: {self.search.success}", msg_type=MSG_TYPE.INFO)
#       self.log.log_msg(msg=self.post.__str__(), msg_type=MSG_TYPE.INFO)
#       # log.log_msg(f" Random numbers generator's seed {options.seed}", MSG_TYPE.INFO)
#       # log.log_msg(" xmin = " + str(self.search.xmin), MSG_TYPE.INFO)
#       # log.log_msg(" hmin = " + str(self.search.xmin.h), MSG_TYPE.INFO)
#       # log.log_msg(" fmin = " + str(self.search.xmin.f), MSG_TYPE.INFO)
#       # log.log_msg(" #bb_eval = " + str(self.search.bb_handle.bb_eval), MSG_TYPE.INFO)
#       # log.log_msg(" nb_success = " + str(self.search.nb_success), MSG_TYPE.INFO)

#     # Failure_check = iteration > 0 and self.search.Failure_stop is not None and self.search.Failure_stop and not self.search.success
#     # if (Failure_check) or (abs(self.search.mesh.msize) < options.tol or self.search.bb_eval >= options.budget or self.search.terminate):
#     #   break
#     # iteration += 1
#     # self.LAMBDA_k = copy.deepcopy(self.search.constraints_RP.LAMBDA)
#     # self.RHO_k = copy.dee

#   def poll_step(self):
#     if self.poll.bb_eval + self.search.bb_eval>= self.options.budget:
#       self.poll.terminate
#       return
#     self.tic = time.perf_counter()
#     self.poll.xmin = self.xmin
#     self.poll.constraints_RP.LAMBDA = self.search.xmin.LAMBDA = self.xmin.LAMBDA = self.poll.xmin.LAMBDA = self.LAMBDA_k
#     self.poll.constraints_RP.RHO = self.search.xmin.RHO = self.xmin.RHO = self.poll.xmin.RHO = self.RHO_k
#     self.poll.constraints_RP.hmax = self.search.xmin.hmax = self.xmin.hmax = self.poll.xmin.hmax
#     self.poll.mesh.update()
#     """ Create the set of poll directions """
#     hhm = self.poll.create_housholder(self.options.rich_direction, domain=self.xmin.var_type)
#     self.poll.lb = self.param.lb
#     self.poll.ub = self.param.ub
#     self.poll.xmin = copy.deepcopy(self.xmin)
#     xmin = copy.deepcopy(self.xmin)
#     xmin.mesh = copy.deepcopy(self.poll.mesh)
#     if self.B._currentIncumbentFeas is not None:
#       self.B._currentIncumbentFeas.mesh = copy.deepcopy(self.poll.mesh)
#     if self.HT is not None:
#       self.poll.hashtable = self.HT
#     if self.B is not None:
#       if isinstance(self.B, Barrier):
#         self.B.insert(xmin)
#         if self.B._filter is not None:
#           self.B.select_poll_center()
#           self.B.update_and_reset_success()
          
#       elif isinstance(self.B, BarrierMO) and self.iteration == 1:
#         self.B.init(evalPointList=[xmin])
        
#     if isinstance(self.B, Barrier):
#         self.poll.constraints_RP.hmax = xmin.hmax
#         self.poll.create_poll_set(hhm=hhm,
#                   ub=self.param.ub,
#                   lb=self.param.lb, it=self.iteration, var_type=xmin.var_type, var_sets=xmin.sets, var_link = xmin.var_link, c_types=self.param.constraints_type, is_prim=True)
#         if self.B._sec_poll_center is not None and self.B._sec_poll_center.evaluated:
#           del self.poll.poll_set
#           # poll.poll_dirs = []
#           self.poll.x_sc = self.B._sec_poll_center
#           self.poll.create_poll_set(hhm=hhm,
#                   ub=self.param.ub,
#                   lb=self.param.lb, it=self.iteration, var_type=self.B._sec_poll_center.var_type, var_sets=self.B._sec_poll_center.sets, var_link = self.B._sec_poll_center.var_link, c_types=self.param.constraints_type, is_prim=False)
#     elif isinstance(self.B, BarrierMO):
#       self.poll.constraints_RP.hmax = self.B._hMax
#       del self.poll.poll_set
#       del self.poll.poll_dirs
#       if self.B._currentIncumbentFeas and self.B._currentIncumbentFeas.evaluated:
#         self.poll.create_poll_set(hhm=hhm,
#                 ub=self.param.ub,
#                 lb=self.param.lb, it=self.iteration, var_type=self.B._currentIncumbentFeas.var_type, var_sets=self.B._currentIncumbentFeas.sets, var_link = self.B._currentIncumbentFeas.var_link, c_types=self.param.constraints_type, is_prim=True)
#       elif self.poll.xmin.status == DESIGN_STATUS.FEASIBLE:
#         self.poll.create_poll_set(hhm=hhm,
#                 ub=self.param.ub,
#                 lb=self.param.lb, it=self.iteration, var_type=self.poll.xmin.var_type, var_sets=self.poll.xmin.sets, var_link = self.poll.xmin.var_link, c_types=self.param.constraints_type, is_prim=True)
      
#       if self.B._currentIncumbentInf and self.B._currentIncumbentInf.evaluated:
#         # del self.poll.poll_set
#         self.poll.x_sc = self.B._currentIncumbentInf
#         self.poll.create_poll_set(hhm=hhm,
#                 ub=self.param.ub,
#                 lb=self.param.lb, it=self.iteration, var_type=self.B._currentIncumbentInf.var_type, var_sets=self.B._currentIncumbentInf.sets, var_link = self.B._currentIncumbentInf.var_link, c_types=self.param.constraints_type, is_prim=False)
#       elif self.poll.xmin.status == DESIGN_STATUS.INFEASIBLE:
#         self.poll.create_poll_set(hhm=hhm,
#                 ub=self.param.ub,
#                 lb=self.param.lb, it=self.iteration, var_type=self.poll.xmin.var_type, var_sets=self.poll.xmin.sets, var_link = self.poll.xmin.var_link, c_types=self.param.constraints_type, is_prim=False)
      
    
#     self.poll.constraints_RP.LAMBDA = self.LAMBDA_k
#     self.poll.constraints_RP.RHO = self.RHO_k
#     self.poll.constraints_RP.constraints_type = copy.deepcopy(self.param.constraints_type)

#     """ Save current poll directions and incumbent solution
#       so they can be saved later in the post dir """
#     if self.options.save_coordinates:
#       self.post.coords.append(self.poll.poll_set)
#       self.post.x_incumbent.append(self.poll.xmin)
#     """ Reset success boolean """
#     self.poll.success = SUCCESS_TYPES.US
#     """ Reset the BB output """
#     self.poll.bb_output = []
#     if self.poll.check_cache:
#       self.poll.omit_duplicates()
    
#     """ Serial evaluation for points in the poll set """
#     self.poll.bb_handle.xmin = self.poll.xmin
#     if not self.options.parallel_mode:
#       xt, self.post, self.peval = self.poll.bb_handle.run_callable_serial_local(iter=self.iteration, peval=self.peval, eval_set=self.poll.poll_set, options=self.options, post=self.post, psize=self.poll.mesh.getDeltaFrameSize().coordinates, stepName=f'Poll Step', constraintsRelaxation=self.poll.constraints_RP.__dict__, budget=self.options.budget)
#       # if self.poll.bb_handle.constraintsRelaxation:
#       #   self.poll.constraints_RP =copy.deepcopy(ConstraintsRelaxationParameters(**self.poll.bb_handle.constraintsRelaxation))

#     else:
#       self.poll.point_index = -1
#       """ Parallel evaluation for points in the poll set """
#       self.poll.bb_eval, xt, self.post, self.peval = self.poll.bb_handle.run_callable_parallel_local(iter=self.iteration, peval=self.peval, njobs=self.options.np, eval_set=self.poll.poll_set, options=self.options, post=self.post, stepName=f'Poll Step', psize=self.poll.mesh.getDeltaFrameSize().coordinates, constraintsRelaxation=self.poll.constraints_RP.__dict__, budget=self.options.budget)
#       # if self.poll.bb_handle.constraintsRelaxation:
#       #   self.poll.constraints_RP = copy.deepcopy(ConstraintsRelaxationParameters(**self.poll.bb_handle.constraintsRelaxation))
#     if self.poll.bb_handle.constraintsRelaxation:
#       temp:ConstraintsRelaxationParameters = ConstraintsRelaxationParameters(**self.poll.bb_handle.constraintsRelaxation)
#       for i in range(len(temp.LAMBDA)):
#         self.poll.constraints_RP.LAMBDA[i] = temp.LAMBDA[i]
#       self.poll.constraints_RP.RHO = temp.RHO
#       self.poll.constraints_RP.constraints_type = temp.constraints_type
#       self.poll.constraints_RP.hmax = temp.hmax
#       # if self.options.store_cache:
#       #   for xi in xt:
#       #     self.poll.hashtable.hash_id = xi
#       #     if not self.poll.hashtable._isPareto:
#       #       self.poll.hashtable.add_to_best_cache(xi)
#     self.poll.postprocess_evaluated_candidates(xt)
#     self.update_poll_step(xt=xt)
#     # self.poll.hashtable = copy.deepcopy(self.HT)
#     self.HT = self.poll.hashtable
  
#   def update_poll_step(self, xt: List[CandidatePoint]):
#     # for xtry in xt:
#     #   self.poll.hashtable.add_to_cache(xtry)

#     # for xtry in xt:
#     #   if not self.poll.hashtable._isPareto:
#     #     self.poll.hashtable.add_to_best_cache(xtry)

#     if isinstance(self.B, Barrier):
#         xpost: List[CandidatePoint] = self.poll.master_updates(xt, self.peval, save_all_best=self.options.save_all_best, save_all=self.options.save_results)
#         xmin = copy.deepcopy(self.poll.xmin)
#         if self.options.save_results:
#           for i in range(len(xpost)):
#             self.post.poll_dirs.append(xpost[i])
#         for xv in xt:
#           if xv.evaluated:
#             self.B.insert(xv)

#         """ Update the xmin in post"""
#         self.post.xmin = copy.deepcopy(self.poll.xmin)

#         """ Updates """
#         pev = 0.
#         for p in self.poll.poll_set:
#           if p.evaluated:
#             pev += 1
#         # if pev != self.poll.poll_dirs and not self.poll.success:
#         #   self.poll.seed += 1
#         goToSearch: bool = (pev == 0 and self.poll.Failure_stop is not None and self.poll.Failure_stop)
        
#         dir: Point = Point(self.poll._n)
#         dir.coordinates = self.poll.xmin.direction.coordinates if self.poll.xmin.direction is not None else [0]*self.poll._n
#         if self.poll.success == SUCCESS_TYPES.FS and not goToSearch:
#           self.poll.mesh.enlargeDeltaFrameSize(direction=dir) # self.poll.mesh.psize =  np.multiply(self.poll.mesh.psize, 2, dtype=self.poll.dtype.dtype
#         elif self.poll.success == SUCCESS_TYPES.US:
#           self.poll.mesh.refineDeltaFrameSize()
#           # self.poll.mesh.psize = np.divide(self.poll.mesh.psize, 2, dtype=self.poll.dtype.dtype)
        
#     elif isinstance(self.B, BarrierMO):
#       xpost: List[CandidatePoint] = []
#       for i in range(len(xt)):
#         xpost.append(xt[i])
#       updated, _, _ = self.B.updateWithPoints(evalPointList=xpost, evalType=None, keepAllPoints=False, updateInfeasibleIncumbentAndHmax=True)
#       if not updated:
#         newMesh = None
#         if self.B._currentIncumbentInf:
#           self.B._currentIncumbentInf.mesh.refineDeltaFrameSize()
#           newMesh = copy.deepcopy(self.B._currentIncumbentFeas.mesh) if self.B._currentIncumbentFeas else copy.deepcopy(self.B._currentIncumbentInf.mesh) if self.B._currentIncumbentInf else None
#           self.B.updateCurrentIncumbents()
#         if self.B._currentIncumbentFeas:
#           self.B._currentIncumbentFeas.mesh.refineDeltaFrameSize()
#           newMesh = copy.deepcopy(self.B._currentIncumbentFeas.mesh) if self.B._currentIncumbentFeas else copy.deepcopy(self.B._currentIncumbentInf.mesh) if self.B._currentIncumbentInf else None
#           self.B.updateCurrentIncumbents()

        
#         if newMesh:
#           self.poll.mesh = newMesh
#         else:
#           self.poll.mesh.refineDeltaFrameSize()
          
#       else:
#         self.poll.mesh = copy.deepcopy(self.B._currentIncumbentFeas.mesh) if self.B._currentIncumbentFeas else copy.deepcopy(self.B._currentIncumbentInf.mesh) if self.B._currentIncumbentInf else self.poll.mesh
#         self.poll.xmin = copy.deepcopy(self.B._currentIncumbentFeas) if self.B._currentIncumbentFeas else copy.deepcopy(self.B._currentIncumbentInf) if self.B._currentIncumbentInf else self.poll.xmin
#       for i in range(len(xpost)):
#         self.post.poll_dirs.append(xpost[i])
      
#       self.post.xmin = self.B._currentIncumbentFeas if self.B._currentIncumbentFeas  else self.B._currentIncumbentInf if  self.B._currentIncumbentInf else self.poll.xmin
#     self.poll.mesh.update()
#     if self.log is not None:
#         self.log.log_msg(msg=self.post.__str__(), msg_type=MSG_TYPE.INFO)
#     if self.options.display:
#       print(self.post)
    
#     self.LAMBDA_k = self.poll.xmin.LAMBDA
#     self.RHO_k = self.poll.xmin.RHO

#     self.toc = time.perf_counter()

#     if self.log is not None:
#       # log.log_msg(msg=" ---Run Summary--- ", msg_type=MSG_TYPE.INFO)
#       self.log.log_msg(msg=f" Run completed in {self.toc - self.tic:.4f} seconds", msg_type=MSG_TYPE.INFO)
#       self.log.log_msg(msg=f" Success status: {self.poll.success}", msg_type=MSG_TYPE.INFO)
#       self.log.log_msg(msg=self.post.__str__(), msg_type=MSG_TYPE.INFO)
#       # log.log_msg(msg=f" Random numbers generator's seed {options.seed}", msg_type=MSG_TYPE.INFO)
#       # log.log_msg(msg=f" xmin = {self.poll.xmin.__str__()} ", msg_type=MSG_TYPE.INFO)
#       # log.log_msg(msg=f" hmin = {self.poll.xmin.h} ", msg_type=MSG_TYPE.INFO)
#       # log.log_msg(msg=f" fmin {self.poll.xmin.fobj}", msg_type=MSG_TYPE.INFO)
#       # log.log_msg(msg=f" #bb_eval =  {self.poll.bb_eval} ", msg_type=MSG_TYPE.INFO)
#       # log.log_msg(msg=f" #iteration =  {iteration} ", msg_type=MSG_TYPE.INFO)
#       # log.log_msg(msg=f"  nb_success = {self.poll.nb_success} ", msg_type=MSG_TYPE.INFO)
#       # log.log_msg(msg=f" psize = {self.poll.mesh.psize} ", msg_type=MSG_TYPE.INFO)
#       # log.log_msg(msg=f" psize_success = {self.poll.mesh.psize_success} ", msg_type=MSG_TYPE.INFO)
#       # log.log_msg(msg=f" psize_max = {self.poll.mesh.psize_max} ", msg_type=MSG_TYPE.INFO)



# def main(*args) -> Dict[str, Any]:
#   """ Otho-MADS main algorithm """
#   # COMPLETED: add more checks for more defensive code

#   """ Parse the parameters files """
#   if type(args[0]) is dict:
#     data = args[0]
#   elif isinstance(args[0], str):
#     if os.path.exists(os.path.abspath(args[0])):
#       _, file_extension = os.path.splitext(args[0])
#       if file_extension == ".json":
#         try:
#           with open(args[0]) as file:
#             data = json.load(file)
#         except ValueError:
#           raise IOError('invalid json file: ' + args[0])
#       else:
#         raise IOError(f"The input file {args[0]} is not a JSON dictionary. "
#                 f"Currently, OMADS supports JSON files solely!")
#     else:
#       raise IOError(f"Couldn't find {args[0]} file!")
#   else:
#     raise IOError("The first input argument couldn't be recognized. "
#             "It should be either a dictionary object or a JSON file that holds "
#             "the required input parameters.")
  
#   """ Initialize the log file """
#   log = logger()
#   if not os.path.exists(data["param"]["post_dir"]):
#      try:
#       os.mkdir(data["param"]["post_dir"])
#      except:
#       os.makedirs(data["param"]["post_dir"], exist_ok=True)

#   log.initialize(data["param"]["post_dir"] + "/OMADS.log")

#   """ Run preprocessor for the setup of
#    the optimization problem and for the initialization
#   of optimization process """
#   MADS_Agent: MADS = MADS(data)
#   MADS_Agent.log = copy.deepcopy(log)
#   # if MADS_LINK.REPLACE is not None and not MADS_LINK.REPLACE:
#   #   out.replace = False

#   """ Set the random seed for results reproducibility """
#   if len(args) < 4:
#     np.random.seed(MADS_Agent.options.seed)
#   else:
#     np.random.seed(int(args[3]))

#   """ Start the count down for calculating the runtime indicator """
#   tic = PS.time.perf_counter()
#   MADS_Agent.peval = 0
#   MADS_Agent.LAMBDA_k = MADS_Agent.xmin.LAMBDA
#   MADS_Agent.RHO_k = MADS_Agent.xmin.RHO

#   if MADS_Agent.search.type == SS.SEARCH_TYPE.VNS.name:
#     MADS_Agent.search_VN = SS.VNS(active_barrier=MADS_Agent.B, params=MADS_Agent.param)
#     MADS_Agent.search_VN._ns_dist = [int(((MADS_Agent.search.dim+1)/2)*((MADS_Agent.search.dim+2)/2)/(len(MADS_Agent.search_VN._dist))) if MADS_Agent.search.ns is None else MADS_Agent.search.ns] * len(MADS_Agent.search_VN._dist)
#     MADS_Agent.search.ns = sum(MADS_Agent.search_VN._ns_dist)
#   else:
#     MADS_Agent.search_VN = None
  
#   MADS_Agent.search.lb = MADS_Agent.param.lb
#   MADS_Agent.search.ub = MADS_Agent.param.ub
#   if not MADS_Agent.param.isPareto:
#     MADS_Agent.HT.add_to_cache(MADS_Agent.xmin)
#     MADS_Agent.HT.add_to_best_cache(MADS_Agent.xmin)

#   while True:
#     """ Run search step (Optional) """
#     # TODO: This rule cannot be generalized -- needs further invistigation
#     # if poll.dim > 10 and poll.mesh.psize >= 1E-4:
#     #   canSearch = False
#     # else:
#     canSearch = True

#     if canSearch and (MADS_Agent.poll.success == SUCCESS_TYPES.US or MADS_Agent.iteration == 1):
#       MADS_Agent.log.log_msg(f"------- Iteration # {MADS_Agent.iteration}: Run the search step -------", MSG_TYPE.INFO)
#       MADS_Agent.search.iter = MADS_Agent.iteration
#       MADS_Agent.search.hashtable = copy.deepcopy(MADS_Agent.HT)

#       MADS_Agent.search_step()
#       MADS_Agent.xmin = MADS_Agent.search.xmin
#       MADS_Agent.poll.xmin = MADS_Agent.search.xmin
#       MADS_Agent.HT = MADS_Agent.search.hashtable
#       MADS_Agent.LAMBDA_k = MADS_Agent.search.constraints_RP.LAMBDA
#       MADS_Agent.RHO_k = MADS_Agent.search.constraints_RP.RHO
#       MADS_Agent.xmin.hmax = MADS_Agent.search.constraints_RP.hmax
#       MADS_Agent.poll.constraints_RP = MADS_Agent.search.constraints_RP
#     """ Run the poll step (Mandatory step) """
#     MADS_Agent.log.log_msg(f"------- Iteration # {MADS_Agent.iteration}: Run the poll step -------", MSG_TYPE.INFO)
#     MADS_Agent.poll.hashtable = copy.deepcopy(MADS_Agent.HT)
#     MADS_Agent.poll_step()
#     MADS_Agent.xmin = MADS_Agent.poll.xmin
#     MADS_Agent.xmin.hmax =MADS_Agent.poll.xmin.hmax
#     MADS_Agent.LAMBDA_k = MADS_Agent.poll.xmin.LAMBDA
#     MADS_Agent.RHO_k = MADS_Agent.poll.xmin.RHO
#     MADS_Agent.search.mesh = MADS_Agent.poll.mesh
#     MADS_Agent.search.psize = MADS_Agent.poll.psize
#     MADS_Agent.search.xmin.hmax = MADS_Agent.poll.xmin.hmax
#     MADS_Agent.B
#     MADS_Agent.search.constraints_RP.LAMBDA = MADS_Agent.poll.xmin.LAMBDA
#     MADS_Agent.search.constraints_RP.RHO = MADS_Agent.poll.xmin.RHO
#     MADS_Agent.poll.constraints_RP.LAMBDA = MADS_Agent.poll.xmin.LAMBDA
#     MADS_Agent.poll.constraints_RP.RHO = MADS_Agent.poll.xmin.RHO
#     MADS_Agent.HT = MADS_Agent.poll.hashtable
#     """ Check stopping criteria"""
#     pt = (all(abs(MADS_Agent.poll.mesh.getDeltaFrameSize().coordinates[pp]) < MADS_Agent.options.tol for pp in range(MADS_Agent.poll._n)))
#     st = (all(abs(MADS_Agent.search.mesh.getdeltaMeshSize().coordinates[pp]) < MADS_Agent.options.tol  for pp in range(MADS_Agent.search.mesh._n)))
#     if MADS_Agent.options.save_results:
#       MADS_Agent.post.output_results(MADS_Agent.out, False)
#       if MADS_Agent.param.isPareto:
#         MADS_Agent.post.nd_points = []
#         for i in range(len(MADS_Agent.B.getAllPoints())):
#           MADS_Agent.post.nd_points.append(MADS_Agent.B.getAllPoints()[i])
#         MADS_Agent.post.output_nd_results(MADS_Agent.outP)
#     if (pt or st or MADS_Agent.search.bb_handle.bb_eval + MADS_Agent.poll.bb_handle.bb_eval >= MADS_Agent.options.budget):
#       MADS_Agent.log.log_msg(f"\n--------------- Termination of MADS  ---------------", MSG_TYPE.INFO)
#       if pt:
#         MADS_Agent.log.log_msg(f"Termination criterion hit: the poll size is below the minimum threshold defined.", MSG_TYPE.INFO)
#       if st:
#         MADS_Agent.log.log_msg(f"Termination criterion hit: the mesh size is below the minimum threshold defined.", MSG_TYPE.INFO)
#       if (MADS_Agent.search.bb_eval + MADS_Agent.poll.bb_eval >= MADS_Agent.options.budget):
#         MADS_Agent.log.log_msg(f"Termination criterion hit: Evaluation budget is exhausted.", MSG_TYPE.INFO)
#       MADS_Agent.log.log_msg(f"----------------------------------------------------\n", MSG_TYPE.INFO)
#       break
#     MADS_Agent.iteration += 1
    

#   toc = PS.time.perf_counter()
#   if isinstance(MADS_Agent.B, BarrierMO):
#     perfM = Metrics(ND_solutions=MADS_Agent.B.getAllPoints(), nobj=MADS_Agent.B._nobj)
#     HV = perfM.hypervolume()

#   """ If benchmarking, then populate the results in the benchmarking output report """
#   if importlib.util.find_spec('BMDFO') and len(args) > 1 and isinstance(args[1], PS.toy.Run):
#     b: PS.toy.Run = args[1]
#     if b.test_suite == "uncon":
#       ncon = 0
#     else:
#       ncon = len(MADS_Agent.xmin.c_ineq)
#     if len(MADS_Agent.poll.bb_output) > 0:
#       b.add_row(name=MADS_Agent.poll.bb_handle.blackbox,
#             run_index=int(args[2]),
#             nv=len(MADS_Agent.param.baseline),
#             nc=ncon,
#             nb_success=MADS_Agent.poll.nb_success,
#             it=MADS_Agent.iteration,
#             BBEVAL=MADS_Agent.poll.bb_eval,
#             runtime=toc - tic,
#             feval=MADS_Agent.poll.bb_handle.bb_eval,
#             hmin=MADS_Agent.poll.xmin.h,
#             fmin=MADS_Agent.poll.xmin.f)
#     print(f"{MADS_Agent.poll.bb_handle.blackbox}: fmin = {MADS_Agent.poll.xmin.f} , hmin= {MADS_Agent.poll.xmin.h:.2f}")

#   elif importlib.util.find_spec('BMDFO') and len(args) > 1 and not isinstance(args[1], toy.Run):
#     raise IOError("Could not find " + args[1] + " in the internal BM suite.")

#   # if options.save_results:
#   #   post.output_results(out)
  
#   out_step: Any = None
#   if MADS_Agent.poll.xmin < MADS_Agent.search.xmin:
#     out_step = MADS_Agent.poll
#   elif MADS_Agent.search.xmin < MADS_Agent.poll.xmin:
#     out_step = MADS_Agent.search
#   else:
#     out_step = MADS_Agent.poll
  
#   if out_step is None:
#     out_step = MADS_Agent.poll
  

#   if MADS_Agent.options.display:
#     print(" end of orthogonal MADS ")
#     print(" Final objective value: " + str(out_step.xmin.f) + ", hmin= " + str(out_step.xmin.h))

#   if MADS_Agent.options.save_coordinates:
#     MADS_Agent.post.output_coordinates(MADS_Agent.out)
  
#   if log is not None:
#     log.log_msg(msg=" --- MADS Run Summary--- ", msg_type=MSG_TYPE.INFO)
#     log.log_msg(msg=f" Run completed in {toc - tic:.4f} seconds", msg_type=MSG_TYPE.INFO)
#     log.log_msg(msg=f" # of successful search steps = {MADS_Agent.search.n_successes}", msg_type=MSG_TYPE.INFO)
#     log.log_msg(msg=f" # of successful poll steps = {MADS_Agent.poll.n_successes}", msg_type=MSG_TYPE.INFO)
#     log.log_msg(msg=f" Run completed in {toc - tic:.4f} seconds", msg_type=MSG_TYPE.INFO)
#     log.log_msg(msg=f" Random numbers generator's seed {MADS_Agent.options.seed}", msg_type=MSG_TYPE.INFO)
#     log.log_msg(msg=f" xmin = {MADS_Agent.poll.xmin.__str__()} ", msg_type=MSG_TYPE.INFO)
#     log.log_msg(msg=f" hmin = {MADS_Agent.poll.xmin.h} ", msg_type=MSG_TYPE.INFO)
#     log.log_msg(msg=f" fmin {MADS_Agent.poll.xmin.fobj}", msg_type=MSG_TYPE.INFO)
#     log.log_msg(msg=f" Search step # BB evals =  {MADS_Agent.search.bb_eval} ", msg_type=MSG_TYPE.INFO)
#     log.log_msg(msg=f" Poll step # BB evals =  {MADS_Agent.poll.bb_eval} ", msg_type=MSG_TYPE.INFO)
#     log.log_msg(msg=f" Total # BB evals =  {MADS_Agent.poll.bb_eval + MADS_Agent.search.bb_eval} ", msg_type=MSG_TYPE.INFO)
#     log.log_msg(msg=f" #iterations =  {MADS_Agent.iteration} ", msg_type=MSG_TYPE.INFO)
#     log.log_msg(msg=f" psize = {MADS_Agent.poll.mesh.getDeltaFrameSize().coordinates} ", msg_type=MSG_TYPE.INFO)
#     log.log_msg(msg=f" psize_success = {MADS_Agent.poll.xmin.mesh.getDeltaFrameSize().coordinates}", msg_type=MSG_TYPE.INFO)
#     if isinstance(MADS_Agent.B, BarrierMO):
#       log.log_msg(msg=f" Hypervolume metric = {HV}", msg_type=MSG_TYPE.INFO)
#     # log.log_msg(msg=f" psize_max = {poll.mesh.psize_max} ", msg_type=MSG_TYPE.INFO)
#   if MADS_Agent.options.display:
#     print("\n ---MADS Run Summary---")
#     print(f" Run completed in {toc - tic:.4f} seconds")
#     print(f" Random numbers generator's seed {MADS_Agent.options.seed}")
#     print(" xmin = " + str(out_step.xmin))
#     print(" hmin = " + str(out_step.xmin.h))
#     print(" fmin = " + str(out_step.xmin.f))
#     print(" #bb_eval = " + str(out_step.bb_eval))
#     print(" #iteration = " + str(MADS_Agent.iteration))
#     print(" nb_success = " + str(MADS_Agent.poll.nb_success + MADS_Agent.search.nb_success))
#     print(" psize = " + str(MADS_Agent.poll.mesh.getDeltaFrameSize().coordinates))
#     print(" psize_success = " + str(MADS_Agent.poll.xmin.mesh.getDeltaFrameSize().coordinates))
#     # print(" psize_max = " + str(poll.mesh.psize_max))
    
#   xmin = out_step.xmin
#   """ Evaluation of the blackbox; get output responses """
#   if xmin.sets is not None and isinstance(xmin.sets,dict):
#     p: List[Any] = []
#     for i in range(len(xmin.var_type)):
#       if (xmin.var_type[i] == PS.VAR_TYPE.DISCRETE or xmin.var_type[i] == PS.VAR_TYPE.CATEGORICAL) and xmin.var_link[i] is not None:
#         p.append(xmin.sets[xmin.var_link[i]][int(xmin.coordinates[i])])
#       else:
#         p.append(xmin.coordinates[i])
#   else:
#     p = xmin.coordinates
#   output: Dict[str, Any] = {"xmin": p,
#                 "fmin": out_step.xmin.f,
#                 "hmin": out_step.xmin.h,
#                 "nbb_evals" : out_step.bb_eval,
#                 "niterations" : MADS_Agent.iteration,
#                 "nb_success": MADS_Agent.poll.nb_success + MADS_Agent.search.nb_success,
#                 "psize": MADS_Agent.poll.mesh.getDeltaFrameSize().coordinates,
#                 "psuccess": MADS_Agent.poll.xmin.mesh.getDeltaFrameSize().coordinates,
#                 # "pmax": poll.mesh.psize_max,
#                 "msize": out_step.mesh.getdeltaMeshSize().coordinates}

#   return output, out_step

# def rosen(x, *argv):
#   x = np.asarray(x)
#   y = [np.sum(100.0 * (x[1:] - x[:-1] ** 2.0) ** 2.0 + (1 - x[:-1]) ** 2.0,
#         axis=0), [0]]
#   return y


# def test_omads_callable_quick():
#   eval = {"blackbox": rosen}
#   param = {"baseline": [-2.0, -2.0],
#        "lb": [-5, -5],
#        "ub": [10, 10],
#        "var_names": ["x1", "x2"],
#        "scaling": 15.0,
#        "post_dir": "./post",
#        "Failure_stop": True}
#   sampling = {
#     "method": 2,
#     "ns": 5,
#     "visualize": False
#   }
#   options = {"seed": 0, "budget": 100000, "tol": 1e-12, "display": True, "check_cache": True, "store_cache": True, "rich_direction": True, "psize_init": 1., "precision": "high"}

#   data = {"evaluator": eval, "param": param, "options": options, "sampling": sampling}

#   out: Dict = main(data)
#   print(out)


# if __name__ == "__main__":
#     freeze_support()
#     p_file: str = os.path.abspath("")

#     """ Check if an input argument is provided"""
#     if len(sys.argv) > 1:
#       p_file = os.path.abspath(sys.argv[1])
#       main(p_file)

#     if (p_file != "" and os.path.exists(p_file)):
#       main(p_file)

#     if p_file == "":
#       raise IOError("Undefined input args."
#               " Please specify an appropriate input (parameters) jason file")

# ------------------------------------------------------------------------------------#
#  Mesh Adaptive Direct Search - ORTHO-MADS (MADS)                                    #
#                                                                                     #
#  Author: Ahmed H. Bayoumy                                                           #
#  email: ahmed.bayoumy@mail.mcgill.ca                                                #
#                                                                                     #
#  This program is free software: you can redistribute it and/or modify it under the  #
#  terms of the GNU Lesser General Public License as published by the Free Software   #
#  Foundation, either version 3 of the License, or (at your option) any later         #
#  version.                                                                           #
#                                                                                     #
#  This program is distributed in the hope that it will be useful, but WITHOUT ANY    #
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A    #
#  PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more details.   #
#                                                                                     #
#  You should have received a copy of the GNU Lesser General Public License along     #
#  with this program. If not, see <http://www.gnu.org/licenses/>.                     #
#                                                                                     #
#  You can find information on OMADS at                                               #
#  https://github.com/Ahmed-Bayoumy/OMADS                                             #
#  Copyright (C) 2022  Ahmed H. Bayoumy                                               #
# ------------------------------------------------------------------------------------#

import copy
import importlib
import json
from multiprocessing import freeze_support
import os
import sys
import OMADS.POLL as PS
import OMADS.SEARCH as SS
from typing import List, Dict, Any
import numpy as np
if importlib.util.find_spec('BMDFO'):
  from BMDFO import toy
import time
from .Point import Point
from .CandidatePoint import CandidatePoint
from ._common import logger, MSG_TYPE
from ._globals import DESIGN_STATUS, SAMPLING_METHOD, SUCCESS_TYPES
from .Barriers import Barrier, BarrierMO
from .Parameters import Parameters
from .Options import Options
from .PostProcess import Output, PostMADS
from .Metrics import Metrics
from .Optimizer import ConstraintsRelaxationParameters
np.set_printoptions(legacy='1.21')


def search_step(iteration: int, search: SS.efficient_exploration = None, B: SS.auto = None, LAMBDA_k: float=None, RHO_k: float=None, search_VN: SS.VNS = None, post: PS.PostMADS=None, out: PS.Output=None, options: PS.Options=None, xmin: SS.CandidatePoint=None, peval: int=0, HT: Any=None, log:logger = None, outP: PS.Output=None):
  """ Reset success boolean """
  search.success = SUCCESS_TYPES.US
  tic = time.perf_counter()
  search.log = log
  search.xmin = xmin
  search.mesh.update()
  search.LAMBDA = LAMBDA_k
  search.RHO = RHO_k
  if HT is not None:
    search.hashtable = HT
  if B is not None:
    if isinstance(B, Barrier):
      B.insert(search.xmin)
      if B._filter is not None:
        B.select_poll_center()
        B.update_and_reset_success()
    elif isinstance(B, BarrierMO) and iteration == 1:
        B.init(evalPointList=[xmin])
      
  
  # search.hmax = B._h_max
  
  if isinstance(B, Barrier):
    search.hmax = B._h_max
    # TODO: Check whether the commented code below is needed
    # if xmin.status == DESIGN_STATUS.FEASIBLE:
    #   B.insert_feasible(search.xmin)
    # elif xmin.status == DESIGN_STATUS.INFEASIBLE:
    #   B.insert_infeasible(search.xmin)
    # else:
    #   B.insert(search.xmin)
  elif isinstance(B, BarrierMO):
    search.hmax = B._hMax
  """ Create the set of poll directions """
  if search.type == SS.SEARCH_TYPE.VNS.name and search_VN is not None:
    search_VN.active_barrier = B
    search._candidate_points_set = search_VN.run()
    if search_VN.stop:
      print("Reached maximum number of VNS iterations!")
      return search, B, post, out, search.LAMBDA, search.RHO, search.xmin, peval, outP
    search.map_samples_from_coords_to_points(samples=search._candidate_points_set)
  else:
    vvp = vvs = []
    bestFeasible: CandidatePoint = B._currentIncumbentFeas if isinstance(B, BarrierMO) else B._best_feasible
    bestInf: CandidatePoint = B._currentIncumbentInf if isinstance(B, BarrierMO) else B.get_best_infeasible()
    if bestFeasible is not None and bestFeasible.evaluated:
      search.xmin = bestFeasible
      vvp, _ = search.generate_sample_points(int(((search.dim+1)/2)*((search.dim+2)/2)) if search.ns is None else search.ns)
    if bestInf is not None and bestInf.evaluated:
    # if B._filter is not None and B.get_best_infeasible().evaluated:
      xmin_bup = search.xmin
      Prim_samples = search._candidate_points_set
      search.xmin = bestInf#B.get_best_infeasible()
      vvs, _ = search.generate_sample_points(int(((search.dim+1)/2)*((search.dim+2)/2)) if search.ns is None else search.ns)
      search._candidate_points_set += Prim_samples
      search.xmin = xmin_bup
    
    if isinstance(vvs, list) and len(vvs) > 0:
      vv = vvp + vvs
    else:
      vv = vvp


  """ Save current poll directions and incumbent solution
    so they can be saved later in the post dir """
  search.omit_duplicates()
  if options.save_coordinates:
    post.coords.append(search._candidate_points_set)
    post.x_incumbent.append(search.xmin)
  """ Reset success boolean """
  search.success = SUCCESS_TYPES.US
  """ Reset the BB output """
  search.bb_output = []
  xt = []
  """ Serial evaluation for points in the poll set """
  if search_VN is not None:
    search.lb = search_VN.params.lb
    search.ub = search_VN.params.ub
  search.bb_handle.xmin = xmin
  search.constraints_RP.LAMBDA = xmin.LAMBDA
  search.constraints_RP.RHO = xmin.RHO
  search.constraints_RP.constraints_type = xmin.constraints_type
  search.constraints_RP.hmax = xmin.hmax
  if not options.parallel_mode:
    xt, post, peval = search.bb_handle.run_callable_serial_local(iter=iteration, peval=peval, eval_set=search._candidate_points_set, options=options, post=post, psize=search.mesh.getDeltaFrameSize().coordinates, stepName=f'Search: {search.type}', mesh=search.mesh, constraintsRelaxation=search.constraints_RP.__dict__, budget=options.budget)

  else:
    search._point_index = -1
    """ Parallel evaluation for points in the samples set """
    search.bb_eval, xt, post, peval = search.bb_handle.run_callable_parallel_local(iter=iteration, peval=peval, njobs=options.np, eval_set=search._candidate_points_set, options=options, post=post, mesh=search.mesh, stepName=f'Search: {search.type}', psize=search.mesh.getDeltaFrameSize().coordinates, constraintsRelaxation=search.constraints_RP.__dict__, budget=options.budget)
    
  if search.bb_handle.constraintsRelaxation:
    temp:ConstraintsRelaxationParameters = ConstraintsRelaxationParameters(**search.bb_handle.constraintsRelaxation)
    for i in range(len(temp.LAMBDA)):
      search.constraints_RP.LAMBDA[i] = temp.LAMBDA[i]
    search.constraints_RP.RHO = temp.RHO
    search.constraints_RP.constraints_type = temp.constraints_type
    search.constraints_RP.hmax = temp.hmax
    # if options.store_cache:
    #   for xi in xt:
    #     search.hashtable.hash_id = xi
    #     if not search.hashtable._isPareto:
    #       search.hashtable.add_to_best_cache(xi)
  LAMBDA_k = search.bb_handle.constraintsRelaxation["LAMBDA"]
  RHO_k = search.bb_handle.constraintsRelaxation["RHO"]
  search.postprocess_evaluated_candidates(xt)

  
    
  if isinstance(B, Barrier):
    xpost: List[CandidatePoint] = search.master_updates(xt, peval, save_all_best=options.save_all_best, save_all=options.save_results)
    if options.save_results:
      for i in range(len(xpost)):
        post.poll_dirs.append(xpost[i])
    for xv in xt:
      if xv.evaluated:
        B.insert(xv)

    """ Update the xmin in post"""
    post.xmin = copy.deepcopy(search.xmin)


    if iteration == 1:
      search.vicinity_ratio = np.ones((len(search.xmin.coordinates),1))
    
    """ Updates """
    
    if search.success == SUCCESS_TYPES.FS:
      dir: Point = Point(search.mesh._n)
      dir.coordinates = search.xmin.direction.coordinates
      # search.mesh.psize = np.multiply(search.mesh.get, 2, dtype=search.dtype.dtype)
      search.mesh.enlargeDeltaFrameSize(direction=dir)
      if search.sampling_t != SAMPLING_METHOD.ACTIVE.name:
        search.update_local_region(region="expand")
    elif search.success == SUCCESS_TYPES.US:
      # search.mesh.psize = np.divide(search.mesh.psize, 2, dtype=search.dtype.dtype)
      search.mesh.refineDeltaFrameSize()
      if search.sampling_t != SAMPLING_METHOD.ACTIVE.name:
        search.update_local_region(region="contract")
  elif isinstance(B, BarrierMO):
    xpost: List[CandidatePoint] = []
    for i in range(len(xt)):
      xpost.append(xt[i])
    updated, updatedF, updatedInf = B.updateWithPoints(evalPointList=xpost, evalType=None, keepAllPoints=False, updateInfeasibleIncumbentAndHmax=True)
    if not updated:
      newMesh = None
      if B._currentIncumbentInf:
        B._currentIncumbentInf.mesh.refineDeltaFrameSize()
        newMesh = copy.deepcopy(B._currentIncumbentFeas.mesh) if B._currentIncumbentFeas else copy.deepcopy(B._currentIncumbentInf.mesh) if B._currentIncumbentInf else None
        B.updateCurrentIncumbents()
        if search.sampling_t != SAMPLING_METHOD.ACTIVE.name:
          search.update_local_region(region="contract")
      if B._currentIncumbentFeas:
        B._currentIncumbentFeas.mesh.refineDeltaFrameSize()
        newMesh = copy.deepcopy(B._currentIncumbentFeas.mesh) if B._currentIncumbentFeas else copy.deepcopy(B._currentIncumbentInf.mesh) if B._currentIncumbentInf else None
        B.updateCurrentIncumbents()
        if search.sampling_t != SAMPLING_METHOD.ACTIVE.name:
          search.update_local_region(region="contract")
      
      if iteration == 1:
        search.vicinity_ratio = np.ones((len(search.xmin.coordinates),1))
      if newMesh:
        search.mesh = newMesh
      else:
        search.mesh.refineDeltaFrameSize()
        if search.sampling_t != SAMPLING_METHOD.ACTIVE.name:
          search.update_local_region(region="contract")
    else:
      search.mesh = copy.deepcopy(B._currentIncumbentFeas.mesh) if updatedF else copy.deepcopy(B._currentIncumbentInf.mesh) if updatedInf else search.mesh
      search.xmin = copy.deepcopy(B._currentIncumbentFeas) if updatedF else copy.deepcopy(B._currentIncumbentInf) if updatedInf else search.xmin
      if search.sampling_t != SAMPLING_METHOD.ACTIVE.name:
        search.update_local_region(region="expand")
    
    for i in range(len(xpost)):
      post.poll_dirs.append(xpost[i])
    search.hashtable.best_hash_ID = []
    search.hashtable.add_to_best_cache(B.getAllPoints())
    post.xmin = B._currentIncumbentFeas if updatedF  else B._currentIncumbentInf if  updatedInf else search.xmin
    
  search.mesh.update()
  
  
  if options.display:
    if log is not None:
      log.log_msg(msg=post.__str__(), msg_type=MSG_TYPE.INFO)
    print(post)

  toc = time.perf_counter()
  if log is not None:
    log.log_msg(f" Run completed in {toc - tic:.4f} seconds", MSG_TYPE.INFO)
    log.log_msg(msg=f" Success status: {search.success}", msg_type=MSG_TYPE.INFO)
    log.log_msg(msg=post.__str__(), msg_type=MSG_TYPE.INFO)
    # log.log_msg(f" Random numbers generator's seed {options.seed}", MSG_TYPE.INFO)
    # log.log_msg(" xmin = " + str(search.xmin), MSG_TYPE.INFO)
    # log.log_msg(" hmin = " + str(search.xmin.h), MSG_TYPE.INFO)
    # log.log_msg(" fmin = " + str(search.xmin.f), MSG_TYPE.INFO)
    # log.log_msg(" #bb_eval = " + str(search.bb_handle.bb_eval), MSG_TYPE.INFO)
    # log.log_msg(" nb_success = " + str(search.nb_success), MSG_TYPE.INFO)

  # Failure_check = iteration > 0 and search.Failure_stop is not None and search.Failure_stop and not search.success
  # if (Failure_check) or (abs(search.mesh.msize) < options.tol or search.bb_eval >= options.budget or search.terminate):
  #   break
  # iteration += 1
  return search, B, post, out, search.LAMBDA, search.RHO, search.xmin, peval, outP

def poll_step(iteration: int, poll: PS.Dirs2n = None, B: SS.auto = None, LAMBDA_k: float=None, RHO_k: float=None, param: PS.Parameters=None, post: PS.PostMADS=None, xmin: PS.CandidatePoint=None, out: PS.Output=None, options: PS.Options=None, peval: int = 0, HT: Any = None, log:logger = None, outP: PS.Output=None):
  tic = time.perf_counter()
  poll.xmin = xmin
  poll.mesh.update()
  """ Create the set of poll directions """
  hhm = poll.create_housholder(options.rich_direction, domain=xmin.var_type)
  poll.lb = param.lb
  poll.ub = param.ub
  poll.xmin = copy.deepcopy(xmin)
  xmin.mesh = copy.deepcopy(poll.mesh)
  if HT is not None:
    poll.hashtable = HT
  if B is not None:
    if isinstance(B, Barrier):
      B.insert(xmin)
      if B._filter is not None:
        B.select_poll_center()
        B.update_and_reset_success()
        
    elif isinstance(B, BarrierMO) and iteration == 1:
      B.init(evalPointList=[xmin])
      
  if isinstance(B, Barrier):
      poll.hmax = xmin.hmax
      poll.create_poll_set(hhm=hhm,
                ub=param.ub,
                lb=param.lb, it=iteration, var_type=xmin.var_type, var_sets=xmin.sets, var_link = xmin.var_link, c_types=param.constraints_type, is_prim=True)
      if B._sec_poll_center is not None and B._sec_poll_center.evaluated:
        del poll.poll_set
        # poll.poll_dirs = []
        poll.x_sc = B._sec_poll_center
        poll.create_poll_set(hhm=hhm,
                ub=param.ub,
                lb=param.lb, it=iteration, var_type=B._sec_poll_center.var_type, var_sets=B._sec_poll_center.sets, var_link = B._sec_poll_center.var_link, c_types=param.constraints_type, is_prim=False)
  elif isinstance(B, BarrierMO):
    poll.hmax = B._hMax
    del poll.poll_set
    del poll.poll_dirs
    if B._currentIncumbentFeas and B._currentIncumbentFeas.evaluated:
      poll.create_poll_set(hhm=hhm,
              ub=param.ub,
              lb=param.lb, it=iteration, var_type=B._currentIncumbentFeas.var_type, var_sets=B._currentIncumbentFeas.sets, var_link = B._currentIncumbentFeas.var_link, c_types=param.constraints_type, is_prim=True)
    elif poll.xmin.status == DESIGN_STATUS.FEASIBLE:
      poll.create_poll_set(hhm=hhm,
              ub=param.ub,
              lb=param.lb, it=iteration, var_type=poll.xmin.var_type, var_sets=poll.xmin.sets, var_link = poll.xmin.var_link, c_types=param.constraints_type, is_prim=True)
    
    if B._currentIncumbentInf and B._currentIncumbentInf.evaluated:
      # del poll.poll_set
      poll.x_sc = B._currentIncumbentInf
      poll.create_poll_set(hhm=hhm,
              ub=param.ub,
              lb=param.lb, it=iteration, var_type=B._currentIncumbentInf.var_type, var_sets=B._currentIncumbentInf.sets, var_link = B._currentIncumbentInf.var_link, c_types=param.constraints_type, is_prim=False)
    elif poll.xmin.status == DESIGN_STATUS.INFEASIBLE:
      poll.create_poll_set(hhm=hhm,
              ub=param.ub,
              lb=param.lb, it=iteration, var_type=poll.xmin.var_type, var_sets=poll.xmin.sets, var_link = poll.xmin.var_link, c_types=param.constraints_type, is_prim=False)
    
  
  poll.LAMBDA = LAMBDA_k
  poll.RHO = RHO_k

  """ Save current poll directions and incumbent solution
    so they can be saved later in the post dir """
  poll.omit_duplicates()
  if options.save_coordinates:
    post.coords.append(poll.poll_set)
    post.x_incumbent.append(poll.xmin)
  """ Reset success boolean """
  poll.success = SUCCESS_TYPES.US
  """ Reset the BB output """
  poll.bb_output = []
  xt = []
  poll.bb_handle.xmin = xmin
  """ Serial evaluation for points in the poll set """
  poll.constraints_RP.LAMBDA = xmin.LAMBDA
  poll.constraints_RP.RHO = xmin.RHO
  poll.constraints_RP.constraints_type = xmin.constraints_type
  poll.constraints_RP.hmax = xmin.hmax
  if not options.parallel_mode:
    xt, post, peval = poll.bb_handle.run_callable_serial_local(iter=iteration, peval=peval, eval_set=poll._candidate_points_set, options=options, post=post, psize=poll.mesh.getDeltaFrameSize().coordinates, stepName=f'Poll Step', mesh=poll.mesh, constraintsRelaxation=poll.constraints_RP.__dict__, budget=options.budget)

  else:
    poll.point_index = -1
    """ Parallel evaluation for points in the samples set """
    poll.bb_eval, xt, post, peval = poll.bb_handle.run_callable_parallel_local(iter=iteration, peval=peval, njobs=options.np, eval_set=poll._candidate_points_set, options=options, post=post, mesh=poll.mesh, stepName=f'Poll Step', psize=poll.mesh.getDeltaFrameSize().coordinates, constraintsRelaxation=poll.constraints_RP.__dict__, budget=options.budget)
    
  if poll.bb_handle.constraintsRelaxation:
    temp:ConstraintsRelaxationParameters = ConstraintsRelaxationParameters(**poll.bb_handle.constraintsRelaxation)
    for i in range(len(temp.LAMBDA)):
      poll.constraints_RP.LAMBDA[i] = temp.LAMBDA[i]
    poll.constraints_RP.RHO = temp.RHO
    poll.constraints_RP.constraints_type = temp.constraints_type
    poll.constraints_RP.hmax = temp.hmax
    # if options.store_cache:
    #   for xi in xt:
    #     poll.hashtable.hash_id = xi
    #     if not poll.hashtable._isPareto:
    #       poll.hashtable.add_to_best_cache(xi)
  LAMBDA_k = poll.bb_handle.constraintsRelaxation["LAMBDA"]
  RHO_k = poll.bb_handle.constraintsRelaxation["RHO"]
  poll.postprocess_evaluated_candidates(xt)

  if isinstance(B, Barrier):
      xpost: List[CandidatePoint] = poll.master_updates(xt, peval, save_all_best=options.save_all_best, save_all=options.save_results)
      xmin = copy.deepcopy(poll.xmin)
      if options.save_results:
        for i in range(len(xpost)):
          post.poll_dirs.append(xpost[i])
      for xv in xt:
        if xv.evaluated:
          B.insert(xv)

      """ Update the xmin in post"""
      post.xmin = copy.deepcopy(poll.xmin)

      """ Updates """
      pev = 0.
      for p in poll.poll_set:
        if p.evaluated:
          pev += 1
      # if pev != poll.poll_dirs and not poll.success:
      #   poll.seed += 1
      goToSearch: bool = (pev == 0 and poll.Failure_stop is not None and poll.Failure_stop)
      
      dir: Point = Point(poll._n)
      dir.coordinates = poll.xmin.direction.coordinates if poll.xmin.direction is not None else [0]*poll._n
      if poll.success == SUCCESS_TYPES.FS and not goToSearch:
        poll.mesh.enlargeDeltaFrameSize(direction=dir) # poll.mesh.psize =  np.multiply(poll.mesh.psize, 2, dtype=poll.dtype.dtype
      elif poll.success == SUCCESS_TYPES.US:
        poll.mesh.refineDeltaFrameSize()
        # poll.mesh.psize = np.divide(poll.mesh.psize, 2, dtype=poll.dtype.dtype)
      
  elif isinstance(B, BarrierMO):
    xpost: List[CandidatePoint] = []
    for i in range(len(xt)):
      xpost.append(xt[i])
    updated, _, _ = B.updateWithPoints(evalPointList=xpost, evalType=None, keepAllPoints=False, updateInfeasibleIncumbentAndHmax=True)
    if not updated:
      newMesh = None
      if B._currentIncumbentInf:
        B._currentIncumbentInf.mesh.refineDeltaFrameSize()
        newMesh = copy.deepcopy(B._currentIncumbentFeas.mesh) if B._currentIncumbentFeas else copy.deepcopy(B._currentIncumbentInf.mesh) if B._currentIncumbentInf else None
        B.updateCurrentIncumbents()
      if B._currentIncumbentFeas:
        B._currentIncumbentFeas.mesh.refineDeltaFrameSize()
        newMesh = copy.deepcopy(B._currentIncumbentFeas.mesh) if B._currentIncumbentFeas else copy.deepcopy(B._currentIncumbentInf.mesh) if B._currentIncumbentInf else None
        B.updateCurrentIncumbents()

      
      if newMesh:
        poll.mesh = newMesh
      else:
        poll.mesh.refineDeltaFrameSize()
        
    else:
      poll.mesh = copy.deepcopy(B._currentIncumbentFeas.mesh) if B._currentIncumbentFeas else copy.deepcopy(B._currentIncumbentInf.mesh) if B._currentIncumbentInf else poll.mesh
      poll.xmin = copy.deepcopy(B._currentIncumbentFeas) if B._currentIncumbentFeas else copy.deepcopy(B._currentIncumbentInf) if B._currentIncumbentInf else poll.xmin
    for i in range(len(xpost)):
      post.poll_dirs.append(xpost[i])
    
    post.xmin = B._currentIncumbentFeas if B._currentIncumbentFeas  else B._currentIncumbentInf if  B._currentIncumbentInf else poll.xmin
  poll.mesh.update()
  if log is not None:
      log.log_msg(msg=post.__str__(), msg_type=MSG_TYPE.INFO)
  if options.display:
    print(post)
  
  LAMBDA_k = poll.LAMBDA
  RHO_k = poll.RHO

  toc = time.perf_counter()

  if log is not None:
    # log.log_msg(msg=" ---Run Summary--- ", msg_type=MSG_TYPE.INFO)
    log.log_msg(msg=f" Run completed in {toc - tic:.4f} seconds", msg_type=MSG_TYPE.INFO)
    log.log_msg(msg=f" Success status: {poll.success}", msg_type=MSG_TYPE.INFO)
    log.log_msg(msg=post.__str__(), msg_type=MSG_TYPE.INFO)
    # log.log_msg(msg=f" Random numbers generator's seed {options.seed}", msg_type=MSG_TYPE.INFO)
    # log.log_msg(msg=f" xmin = {poll.xmin.__str__()} ", msg_type=MSG_TYPE.INFO)
    # log.log_msg(msg=f" hmin = {poll.xmin.h} ", msg_type=MSG_TYPE.INFO)
    # log.log_msg(msg=f" fmin {poll.xmin.fobj}", msg_type=MSG_TYPE.INFO)
    # log.log_msg(msg=f" #bb_eval =  {poll.bb_eval} ", msg_type=MSG_TYPE.INFO)
    # log.log_msg(msg=f" #iteration =  {iteration} ", msg_type=MSG_TYPE.INFO)
    # log.log_msg(msg=f"  nb_success = {poll.nb_success} ", msg_type=MSG_TYPE.INFO)
    # log.log_msg(msg=f" psize = {poll.mesh.psize} ", msg_type=MSG_TYPE.INFO)
    # log.log_msg(msg=f" psize_success = {poll.mesh.psize_success} ", msg_type=MSG_TYPE.INFO)
    # log.log_msg(msg=f" psize_max = {poll.mesh.psize_max} ", msg_type=MSG_TYPE.INFO)
  
  return poll, B, post, out, poll.xmin.LAMBDA, poll.xmin.RHO, poll.xmin, peval, outP

def main(*args) -> Dict[str, Any]:
  """ Otho-MADS main algorithm """
  # COMPLETED: add more checks for more defensive code

  """ Parse the parameters files """
  if type(args[0]) is dict:
    data = args[0]
  elif isinstance(args[0], str):
    if os.path.exists(os.path.abspath(args[0])):
      _, file_extension = os.path.splitext(args[0])
      if file_extension == ".json":
        try:
          with open(args[0]) as file:
            data = json.load(file)
        except ValueError:
          raise IOError('invalid json file: ' + args[0])
      else:
        raise IOError(f"The input file {args[0]} is not a JSON dictionary. "
                f"Currently, OMADS supports JSON files solely!")
    else:
      raise IOError(f"Couldn't find {args[0]} file!")
  else:
    raise IOError("The first input argument couldn't be recognized. "
            "It should be either a dictionary object or a JSON file that holds "
            "the required input parameters.")
  
  """ Initialize the log file """
  log = logger()
  if not os.path.exists(data["param"]["post_dir"]):
     try:
      os.mkdir(data["param"]["post_dir"])
     except:
      os.makedirs(data["param"]["post_dir"], exist_ok=True)

  log.initialize(data["param"]["post_dir"] + "/OMADS.log")

  """ Run preprocessor for the setup of
   the optimization problem and for the initialization
  of optimization process """
  iteration: int
  xmin: CandidatePoint
  options: Options
  param: Parameters 
  post: PostMADS 
  out: Output 
  B: Barrier
  poll: PS.Dirs2n
  search: SS.efficient_exploration
  log.log_msg(msg="Preprocess the search step...", msg_type=PS.MSG_TYPE.INFO)
  _, _, search, _, _, _, _, _, _ = SS.PreExploration(data).initialize_from_dict(log=log)
  log.log_msg(msg="Preprocess the MADS algorithim...", msg_type=PS.MSG_TYPE.INFO)
  iteration, xmin, poll, options, param, post, out, B, outP = PS.PrePoll(data).initialize_from_dict(log=log, xs=search.xmin)
  out.stepName = "Poll"
  post.step_name = [f'Search: {search.type}']

  HT = poll.hashtable
  
  # if MADS_LINK.REPLACE is not None and not MADS_LINK.REPLACE:
  #   out.replace = False

  """ Set the random seed for results reproducibility """
  if len(args) < 4:
    np.random.seed(options.seed)
  else:
    np.random.seed(int(args[3]))

  """ Start the count down for calculating the runtime indicator """
  tic = PS.time.perf_counter()
  peval = 0
  LAMBDA_k = xmin.LAMBDA
  RHO_k = xmin.RHO

  if search.type == SS.SEARCH_TYPE.VNS.name:
    search_VN = SS.VNS(active_barrier=B, params=param)
    search_VN._ns_dist = [int(((search.dim+1)/2)*((search.dim+2)/2)/(len(search_VN._dist))) if search.ns is None else search.ns] * len(search_VN._dist)
    search.ns = sum(search_VN._ns_dist)
  else:
    search_VN = None
  
  search.lb = param.lb
  search.ub = param.ub

  while True:
    """ Run search step (Optional) """
    # TODO: This rule cannot be generalized -- needs further invistigation
    # if poll.dim > 10 and poll.mesh.psize >= 1E-4:
    #   canSearch = False
    # else:
    canSearch = True

    if canSearch and (poll.success == SUCCESS_TYPES.US or iteration == 1):
      log.log_msg(f"------- Iteration # {iteration}: Run the search step -------", MSG_TYPE.INFO)
      search.iter = iteration
      search, B, post, out, LAMBDA_k, RHO_k, xmin, peval, outP = search_step(search=search, B=B, LAMBDA_k=LAMBDA_k, RHO_k=RHO_k, iteration=iteration , search_VN=search_VN, post=post, out=out, options=options, xmin=xmin, peval=peval, HT=HT, log=log, outP=outP)
      HT = search.hashtable
    """ Run the poll step (Mandatory step) """
    log.log_msg(f"------- Iteration # {iteration}: Run the poll step -------", MSG_TYPE.INFO)
    poll, B, post, out, LAMBDA_k, RHO_k, xmin, peval, outP = poll_step(iteration=iteration, poll=poll, B=B, LAMBDA_k=LAMBDA_k, RHO_k=RHO_k, param=param, post=post, xmin=xmin, out=out, options=options, peval=peval, HT=HT, log=log, outP=outP)
    HT = poll.hashtable
    xmin = poll.xmin
    search.mesh = copy.deepcopy(poll.mesh)
    search.psize = copy.deepcopy(poll.psize)
    """ Check stopping criteria"""
    pt = (all(abs(poll.mesh.getDeltaFrameSize().coordinates[pp]) < options.tol for pp in range(poll._n)))
    st = (all(abs(search.mesh.getdeltaMeshSize().coordinates[pp]) < options.tol  for pp in range(search.mesh._n)))
    if options.save_results:
      post.output_results(out, False)
      if param.isPareto:
        post.nd_points = []
        for i in range(len(B.getAllPoints())):
          post.nd_points.append(B.getAllPoints()[i])
        post.output_nd_results(outP)
    if (pt or st or search.bb_eval + poll.bb_eval >= options.budget):
      log.log_msg(f"\n--------------- Termination of MADS  ---------------", MSG_TYPE.INFO)
      if pt:
        log.log_msg(f"Termination criterion hit: the poll size is below the minimum threshold defined.", MSG_TYPE.INFO)
      if st:
        log.log_msg(f"Termination criterion hit: the mesh size is below the minimum threshold defined.", MSG_TYPE.INFO)
      if (search.bb_eval + poll.bb_eval >= options.budget):
        log.log_msg(f"Termination criterion hit: Evaluation budget is exhausted.", MSG_TYPE.INFO)
      log.log_msg(f"----------------------------------------------------\n", MSG_TYPE.INFO)
      break
    iteration += 1
    

  toc = PS.time.perf_counter()
  if isinstance(B, BarrierMO):
    perfM = Metrics(ND_solutions=B.getAllPoints(), nobj=B._nobj)
    HV = perfM.hypervolume()

  """ If benchmarking, then populate the results in the benchmarking output report """
  if importlib.util.find_spec('BMDFO') and len(args) > 1 and isinstance(args[1], PS.toy.Run):
    b: PS.toy.Run = args[1]
    if b.test_suite == "uncon":
      ncon = 0
    else:
      ncon = len(xmin.c_ineq)
    if len(poll.bb_output) > 0:
      b.add_row(name=poll.bb_handle.blackbox,
            run_index=int(args[2]),
            nv=len(param.baseline),
            nc=ncon,
            nb_success=poll.nb_success,
            it=iteration,
            BBEVAL=poll.bb_eval,
            runtime=toc - tic,
            feval=poll.bb_handle.bb_eval,
            hmin=poll.xmin.h,
            fmin=poll.xmin.f)
    print(f"{poll.bb_handle.blackbox}: fmin = {poll.xmin.f} , hmin= {poll.xmin.h:.2f}")

  elif importlib.util.find_spec('BMDFO') and len(args) > 1 and not isinstance(args[1], toy.Run):
    raise IOError("Could not find " + args[1] + " in the internal BM suite.")

  # if options.save_results:
  #   post.output_results(out)
  
  out_step: Any = None
  if poll.xmin < search.xmin:
    out_step = poll
  elif search.xmin < poll.xmin:
    out_step = search
  else:
    out_step = poll
  
  if out_step is None:
    out_step = poll
  

  if options.display:
    print(" end of orthogonal MADS ")
    print(" Final objective value: " + str(out_step.xmin.f) + ", hmin= " + str(out_step.xmin.h))

  if options.save_coordinates:
    post.output_coordinates(out)
  
  if log is not None:
    log.log_msg(msg=" --- MADS Run Summary--- ", msg_type=MSG_TYPE.INFO)
    log.log_msg(msg=f" Run completed in {toc - tic:.4f} seconds", msg_type=MSG_TYPE.INFO)
    log.log_msg(msg=f" # of successful search steps = {search.n_successes}", msg_type=MSG_TYPE.INFO)
    log.log_msg(msg=f" # of successful poll steps = {poll.n_successes}", msg_type=MSG_TYPE.INFO)
    log.log_msg(msg=f" Run completed in {toc - tic:.4f} seconds", msg_type=MSG_TYPE.INFO)
    log.log_msg(msg=f" Random numbers generator's seed {options.seed}", msg_type=MSG_TYPE.INFO)
    log.log_msg(msg=f" xmin = {poll.xmin.__str__()} ", msg_type=MSG_TYPE.INFO)
    log.log_msg(msg=f" hmin = {poll.xmin.h} ", msg_type=MSG_TYPE.INFO)
    log.log_msg(msg=f" fmin {poll.xmin.fobj}", msg_type=MSG_TYPE.INFO)
    log.log_msg(msg=f" Search step # BB evals =  {search.bb_eval} ", msg_type=MSG_TYPE.INFO)
    log.log_msg(msg=f" Poll step # BB evals =  {poll.bb_eval} ", msg_type=MSG_TYPE.INFO)
    log.log_msg(msg=f" Total # BB evals =  {poll.bb_eval + search.bb_eval} ", msg_type=MSG_TYPE.INFO)
    log.log_msg(msg=f" #iterations =  {iteration} ", msg_type=MSG_TYPE.INFO)
    log.log_msg(msg=f" psize = {poll.mesh.getDeltaFrameSize().coordinates} ", msg_type=MSG_TYPE.INFO)
    log.log_msg(msg=f" psize_success = {poll.xmin.mesh.getDeltaFrameSize().coordinates}", msg_type=MSG_TYPE.INFO)
    if isinstance(B, BarrierMO):
      log.log_msg(msg=f" Hypervolume metric = {HV}", msg_type=MSG_TYPE.INFO)
    # log.log_msg(msg=f" psize_max = {poll.mesh.psize_max} ", msg_type=MSG_TYPE.INFO)
  if options.display:
    print("\n ---MADS Run Summary---")
    print(f" Run completed in {toc - tic:.4f} seconds")
    print(f" Random numbers generator's seed {options.seed}")
    print(" xmin = " + str(out_step.xmin))
    print(" hmin = " + str(out_step.xmin.h))
    print(" fmin = " + str(out_step.xmin.f))
    print(" #bb_eval = " + str(out_step.bb_eval))
    print(" #iteration = " + str(iteration))
    print(" nb_success = " + str(poll.nb_success + search.nb_success))
    print(" psize = " + str(poll.mesh.getDeltaFrameSize().coordinates))
    print(" psize_success = " + str(poll.xmin.mesh.getDeltaFrameSize().coordinates))
    # print(" psize_max = " + str(poll.mesh.psize_max))
    
  xmin = out_step.xmin
  """ Evaluation of the blackbox; get output responses """
  if xmin.sets is not None and isinstance(xmin.sets,dict):
    p: List[Any] = []
    for i in range(len(xmin.var_type)):
      if (xmin.var_type[i] == PS.VAR_TYPE.DISCRETE or xmin.var_type[i] == PS.VAR_TYPE.CATEGORICAL) and xmin.var_link[i] is not None:
        p.append(xmin.sets[xmin.var_link[i]][int(xmin.coordinates[i])])
      else:
        p.append(xmin.coordinates[i])
  else:
    p = xmin.coordinates
  output: Dict[str, Any] = {"xmin": p,
                "fmin": out_step.xmin.f,
                "hmin": out_step.xmin.h,
                "nbb_evals" : out_step.bb_eval,
                "niterations" : iteration,
                "nb_success": poll.nb_success + search.nb_success,
                "psize": poll.mesh.getDeltaFrameSize().coordinates,
                "psuccess": poll.xmin.mesh.getDeltaFrameSize().coordinates,
                # "pmax": poll.mesh.psize_max,
                "msize": out_step.mesh.getdeltaMeshSize().coordinates}

  return output, out_step


def rosen(x, *argv):
  x = np.asarray(x)
  y = [np.sum(100.0 * (x[1:] - x[:-1] ** 2.0) ** 2.0 + (1 - x[:-1]) ** 2.0,
        axis=0), [0]]
  return y


def test_omads_callable_quick():
  eval = {"blackbox": rosen}
  param = {"baseline": [-2.0, -2.0],
       "lb": [-5, -5],
       "ub": [10, 10],
       "var_names": ["x1", "x2"],
       "scaling": 15.0,
       "post_dir": "./post",
       "Failure_stop": True}
  sampling = {
    "method": 2,
    "ns": 5,
    "visualize": False
  }
  options = {"seed": 0, "budget": 100000, "tol": 1e-12, "display": True, "check_cache": True, "store_cache": True, "rich_direction": True, "psize_init": 1., "precision": "high"}

  data = {"evaluator": eval, "param": param, "options": options, "sampling": sampling}

  out: Dict = main(data)
  print(out)


if __name__ == "__main__":
    freeze_support()
    p_file: str = os.path.abspath("")

    """ Check if an input argument is provided"""
    if len(sys.argv) > 1:
      p_file = os.path.abspath(sys.argv[1])
      main(p_file)

    if (p_file != "" and os.path.exists(p_file)):
      main(p_file)

    if p_file == "":
      raise IOError("Undefined input args."
              " Please specify an appropriate input (parameters) jason file")